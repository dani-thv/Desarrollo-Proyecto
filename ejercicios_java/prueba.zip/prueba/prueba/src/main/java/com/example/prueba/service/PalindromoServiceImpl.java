package com.example.prueba.service;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class PalindromoServiceImpl implements PalidromoService{

    @Override
    public ResponseEntity<Boolean> esPalindromo(String pla) {
        StringBuffer sb = new StringBuffer();
        sb.append(pla);
        return new ResponseEntity<Boolean>(sb.reverse().toString().equals(pla), HttpStatus.OK);
    }
}
