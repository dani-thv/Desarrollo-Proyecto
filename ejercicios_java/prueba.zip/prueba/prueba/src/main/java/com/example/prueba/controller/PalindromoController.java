package com.example.prueba.controller;

import com.example.prueba.service.PalidromoService;
import com.example.prueba.service.SaludarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/examen")
public class PalindromoController {

    @Autowired
    private PalidromoService palidromoService;

    @GetMapping("/asd/{palabra}")
    public ResponseEntity<String> asd(@PathVariable String palabra) {
        return this.palidromoService.esPalindromo(palabra).getBody() ? new ResponseEntity<String>("Es Palindromo", HttpStatus.OK): new ResponseEntity<String>("No es Palindromo", HttpStatus.OK);
    }
}
