package com.example.prueba.service;

import org.springframework.http.ResponseEntity;

public interface PalidromoService {
    ResponseEntity<Boolean> esPalindromo(String pla);
}
