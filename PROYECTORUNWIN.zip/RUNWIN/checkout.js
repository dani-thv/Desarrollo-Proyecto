
function getImagenSrc(nombre) {

    if (!nombre) {
        return "https://placehold.co/400x400?text=Sin+Imagen";
    }

    // Si la imagen empieza por un número → significa que viene del backend (/uploads/)
    if (/^\d/.test(nombre)) {
        return `http://localhost:8081/uploads/${nombre}`;
    }

    // Si NO empieza por número → imagen vieja del frontend
    return `${nombre}`;
}

document.addEventListener("DOMContentLoaded", async () => {

    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (!usuario) {
        window.location.href = "inicio_sesion.html";
        return;
    }

    // Rellenar datos del usuario
    document.getElementById("nombre").value = usuario.nombre || "";
    document.getElementById("apellidos").value = usuario.apellidos || "";
    document.getElementById("direccion").value = usuario.direccion || "";
    document.getElementById("correo").value = usuario.correo || "";
    document.getElementById("telefono").value = usuario.telefono || "";

    // Cargar carrito del usuario
    const res = await fetch(`http://localhost:8081/api/carrito/${usuario.id}`);
    const items = await res.json();

    const lista = document.getElementById("checkout-items");
    let subtotal = 0;

items.forEach(item => {
    
    const imagenUrl = getImagenSrc(item.imagen);

    lista.innerHTML += `
        <div class="checkout-item">
            <img src="${imagenUrl}" class="checkout-img">
            <div>
                <p>${item.nombre}</p>
                <strong>COP ${item.precioFinal.toLocaleString("es-CO")}</strong>
            </div>
        </div>
    `;

    subtotal += item.subtotal;
});


    document.getElementById("subtotal").textContent = subtotal.toLocaleString("es-CO");
    document.getElementById("total").textContent = subtotal.toLocaleString("es-CO");
});




async function procesarPedido() {

    const usuario = JSON.parse(localStorage.getItem("usuario"));

    const nombre = document.getElementById("nombre").value.trim();
    const apellidos = document.getElementById("apellidos").value.trim();
    const direccion = document.getElementById("direccion").value.trim();
    const departamento = document.getElementById("departamento").value;
    const ciudad = document.getElementById("ciudad").value;
    const postal = document.getElementById("postal").value.trim();
    const correo = document.getElementById("correo").value.trim();
    const telefono = document.getElementById("telefono").value.trim();
    const metodoPago = document.querySelector("input[name='metodo']:checked")?.value;
    const notas = document.getElementById("notas").value;

    if (!nombre || !apellidos || !direccion || !departamento || !ciudad || !postal || !correo || !telefono || !metodoPago) {
        alert("Debe completar todos los campos obligatorios.");
        return;
    }


    const carritoRes = await fetch(`http://localhost:8081/api/carrito/${usuario.id}`);
    const items = await carritoRes.json();

    let total = 0;
    items.forEach(item => total += item.subtotal);


    const pedidoRes = await fetch("http://localhost:8081/api/pedidos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            usuarioId: usuario.id,
            nombre,
            apellidos,
            direccion,
            departamento,
            ciudad,
            codigoPostal: postal,
            correo,
            telefono,
            metodoPago,
            notas,
            total   
        })
    });

    const pedido = await pedidoRes.json();


    for (const item of items) {
        await fetch("http://localhost:8081/api/pedidos/detalle", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                pedidoId: pedido.id,
                productoId: item.productoId,
                cantidad: item.cantidad,
                precioUnitario: item.precioFinal   
            })
        });
    }

  
    await fetch(`http://localhost:8081/api/carrito/vaciar/${usuario.id}`, {
        method: "DELETE"
    });

   
    alert("Pedido realizado con éxito 🎉");
    window.location.href = "historial_compras.html";
}
