document.addEventListener("DOMContentLoaded", async () => {

    const usuario = JSON.parse(localStorage.getItem("usuario"));

    // Seguridad: Solo ADMIN puede entrar
    if (!usuario || usuario.rol !== "ADMIN") {
        window.location.href = "panel.html";
        return;
    }

    // Botón cerrar sesión
    document.getElementById("btnSalir").addEventListener("click", () => {
        localStorage.removeItem("usuario");
        window.location.href = "inicio_sesion.html";
    });

    // 1. CARGAR TOTAL DE PRODUCTOS + TABLA DE PRODUCTOS

    try {
        const r1 = await fetch("http://localhost:8081/api/productos");
        const productos = await r1.json();

        // Total productos
        document.getElementById("totalProductos").textContent = productos.length;

        // Tabla de productos
        const tbody = document.getElementById("tablaProductos");
        tbody.innerHTML = "";

        productos.forEach(p => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${p.id}</td>
                <td>${p.nombre}</td>
                <td>COP ${p.precio.toLocaleString()}</td>
                <td>${p.stock}</td>
            `;
            tbody.appendChild(tr);
        });

    } catch (err) {
        console.error("Error cargando productos:", err);
    }


    // 2. CARGAR TOTAL DE USUARIOS


    try {
        const r2 = await fetch("http://localhost:8081/api/usuarios");
        const usuarios = await r2.json();
        document.getElementById("totalUsuarios").textContent = usuarios.length;

    } catch (err) {
        console.error("Error cargando usuarios:", err);
    }


    // 3. CARGAR TOTAL DE PEDIDOS 


    try {
        const r3 = await fetch("http://localhost:8081/api/pedidos");

        if (r3.ok) {
            const pedidos = await r3.json();
            document.getElementById("totalPedidos").textContent = pedidos.length;
        } else {
            document.getElementById("totalPedidos").textContent = "0";
        }

    } catch (err) {
        document.getElementById("totalPedidos").textContent = "0";
        console.warn("Pedidos no disponibles");
    }

});
