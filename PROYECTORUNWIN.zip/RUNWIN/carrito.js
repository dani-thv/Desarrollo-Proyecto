function getImagenSrc(nombre) {

    if (!nombre) {
        return "https://placehold.co/400x400?text=Sin+Imagen";
    }

    // Si empieza por un número → imagen subida guardada en /uploads/
    if (/^\d/.test(nombre)) {
        return `http://localhost:8081/uploads/${nombre}`;
    }

    // Si NO empieza por número → imagen del frontend
    return `${nombre}`;
}

function requireLogin() {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (!usuario) {
        alert("Debes iniciar sesión para continuar");
        window.location.href = "inicio_sesion.html";
        return null;
    }
    return usuario;
}

document.addEventListener("DOMContentLoaded", () => {
    cargarCarrito();
});


async function cargarCarrito() {

    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (!usuario) {
        window.location.href = "inicio_sesion.html";
        return;
    }

    console.log("ID usuario:", usuario.id);

    const response = await fetch(`http://localhost:8081/api/carrito/${usuario.id}`);
    const items = await response.json();

    console.log("Items carrito:", items);

    const tbody = document.querySelector(".cart-table tbody");
    tbody.innerHTML = "";

    let total = 0;

    items.forEach(item => {

        const subtotal = Number(item.subtotal);
        total += subtotal;

        const imagenUrl = getImagenSrc(item.imagen);

        const row = document.createElement("tr");
        row.dataset.itemId = item.id; 

        row.innerHTML = `
            <td class="product-info">
                <img src="${imagenUrl}" class="product-img">
                <div class="product-text">
                    <strong>${item.nombre}</strong>
                </div>
            </td>

            <td class="price">
                COP ${Number(item.precioFinal).toLocaleString("es-CO")}
                ${item.porcentaje > 0 ? `
                    <br><small class="old-price">
                        Antes: ${Number(item.precioOriginal).toLocaleString("es-CO")}
                    </small>
                ` : ""}
            </td>

            <td class="qty-cell">
                <button class="qty-btn" onclick="changeQty(${item.id}, ${item.cantidad - 1})">-</button>
                <span class="quantity">${item.cantidad}</span>
                <button class="qty-btn" onclick="changeQty(${item.id}, ${item.cantidad + 1})">+</button>
            </td>

            <td class="subtotal">
                <span>COP ${subtotal.toLocaleString("es-CO")}</span>
                <button class="remove-item" onclick="removeItem(${item.id})">✕</button>
            </td>
        `;

        tbody.appendChild(row);
    });

    document.getElementById("subtotal").textContent = "COP " + total.toLocaleString("es-CO");
    document.getElementById("total").textContent = "COP " + total.toLocaleString("es-CO");
}




async function changeQty(itemId, nuevaCantidad) {

    if (nuevaCantidad <= 0) {
        removeItem(itemId);
        return;
    }

    await fetch(`http://localhost:8081/api/carrito/item/${itemId}?cantidad=${nuevaCantidad}`, {
        method: "PUT"
    });

    cargarCarrito();
}




async function removeItem(itemId) {

    await fetch(`http://localhost:8081/api/carrito/item/${itemId}`, {
        method: "DELETE"
    });

    cargarCarrito();
}



async function agregarAlCarrito(productoId) {

    const usuario = requireLogin();
    if (!usuario) return; // SE BLOQUEA

    try {
        const response = await fetch(`http://localhost:8081/api/carrito/${usuario.id}/agregar/${productoId}`, {
            method: "POST"
        });

        const data = await response.json();
        alert("✔️Producto agregado al carrito ");

    } catch (error) {
        console.error("Error al agregar al carrito", error);
    }
}




// =======================================================
// 🔹 Cerrar sesión
// =======================================================
const btnCerrar = document.getElementById("cerrar-sesion");
if (btnCerrar) {
    btnCerrar.addEventListener("click", () => {
        localStorage.removeItem("usuario");
        window.location.href = "inicio_sesion.html";
    });
}

document.querySelector(".checkout-btn").addEventListener("click", () => {
    window.location.href = "checkout.html";
});
