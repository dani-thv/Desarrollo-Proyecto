/* ===========================================
   SCRIPT GENERAL PARA RUNWIN
   Archivo base — puedes agregar funciones aquí
=========================================== */

/* --- 1. Confirmación del formulario de suscripción --- */
const subscribeBtn = document.querySelector(".subscribe-form button");
const emailInput = document.querySelector(".subscribe-form input");

if (subscribeBtn && emailInput) {
    subscribeBtn.addEventListener("click", (e) => {
        e.preventDefault();

        if (emailInput.value.trim() === "") {
            alert("Por favor ingresa un correo válido.");
            return;
        }

        alert("¡Gracias por suscribirte a RUNWIN!");
        emailInput.value = "";
    });
}

/* --- 2. Animación suave para botones con clase .btn-primary --- */
const buttons = document.querySelectorAll(".btn-primary");

buttons.forEach(btn => {
    btn.addEventListener("mouseenter", () => {
        btn.style.transform = "scale(1.05)";
    });
    btn.addEventListener("mouseleave", () => {
        btn.style.transform = "scale(1)";
    });
});

/* --- 3. Efecto de fade al hacer scroll --- */
window.addEventListener("scroll", () => {
    const elements = document.querySelectorAll(".fade-on-scroll");

    elements.forEach(el => {
        const rect = el.getBoundingClientRect();

        if (rect.top < window.innerHeight - 50) {
            el.style.opacity = "1";
            el.style.transform = "translateY(0)";
        }
    });
});

let currentReview = 0;

const track = document.querySelector(".reviews-track");
const cards = document.querySelectorAll(".review-card");

document.querySelector(".next-review").addEventListener("click", () => {
    if (currentReview < cards.length - 1) {
        currentReview++;
        track.style.transform = `translateX(-${currentReview * 370}px)`;
    }
});

document.querySelector(".prev-review").addEventListener("click", () => {
    if (currentReview > 0) {
        currentReview--;
        track.style.transform = `translateX(-${currentReview * 370}px)`;
    }
});
