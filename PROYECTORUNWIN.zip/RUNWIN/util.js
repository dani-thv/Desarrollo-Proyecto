function getImagenSrc(nombre) {

    if (!nombre) {
        return "https://placehold.co/400x400?text=Sin+Imagen";
    }

    // Si la imagen empieza con un número → backend/uploads
    if (/^\d/.test(nombre)) {
        return `http://localhost:8081/uploads/${nombre}`;
    }

    // Si NO empieza con número → es del frontend
    return `imagenes/productos/${nombre}`;
}
