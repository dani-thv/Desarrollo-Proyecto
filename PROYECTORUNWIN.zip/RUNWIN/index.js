const productos = [
    { img: "imagenes/productos/producto1.png", nombre: "Tenis Running AirMax Pro", precio: "COP 320.000", anterior: "COP 450.000" },
    { img: "imagenes/productos/producto2.jpg", nombre: "Camiseta Deportiva DryFit Hombre", precio: "COP 45.000", anterior: null },
    { img: "imagenes/productos/producto3.jpeg", nombre: "Gorra Visera Ligera", precio: "COP 25.000", anterior: null },
    { img: "imagenes/productos/producto4.jpg", nombre: "Morral Camelbak Pro 2L", precio: "COP 199.000", anterior: "COP 240.000" },
    { img: "imagenes/productos/producto5.jpg", nombre: "Balón Fútbol Profesional", precio: "COP 80.000", anterior: null },
    { img: "imagenes/productos/producto6.jpg", nombre: "Botella Deportiva 750ml", precio: "COP 18.000", anterior: null },
    { img: "imagenes/productos/producto7.jpg", nombre: "Pesa Rusa Kettlebell 10KG", precio: "COP 95.000", anterior: "COP 120.000" },
    { img: "imagenes/productos/producto8.png", nombre: "Audífonos Bluetooth Deportivos V5.1", precio: "COP 130.000", anterior: "COP 180.000" },
    { img: "imagenes/productos/producto9.png", nombre: "Gafas Running Full UV400", precio: "COP 95.000", anterior: null },
    { img: "imagenes/productos/producto10.jpg", nombre: "Guantes de Gimnasio Antideslizantes", precio: "COP 35.000", anterior: null },
    { img: "imagenes/productos/producto11.jpg", nombre: "Bandas de Resistencia Set 5pcs", precio: "COP 50.000", anterior: null },
    { img: "imagenes/productos/producto12.jpg", nombre: "Short Deportivo Hombre", precio: "COP 40.000", anterior: null },
    { img: "imagenes/productos/producto13.jpg", nombre: "Proteína Whey 2LB Chocolate", precio: "COP 139.000", anterior: "COP 180.000" },
    { img: "imagenes/productos/producto14.jpg", nombre: "Cuerda de Salto Pro", precio: "COP 22.000", anterior: null },
    { img: "imagenes/productos/producto15.jpg", nombre: "Rodillera Deportiva Elástica", precio: "COP 32.000", anterior: null },
    { img: "imagenes/productos/producto16.jpg", nombre: "Tobilleras de Peso 2KG", precio: "COP 55.000", anterior: null },
    { img: "imagenes/productos/producto17.jpg", nombre: "Top Deportivo Mujer", precio: "COP 38.000", anterior: null },
    { img: "imagenes/productos/producto18.png", nombre: "Leggings Deportivos Mujer", precio: "COP 60.000", anterior: "COP 75.000" },
    { img: "imagenes/productos/producto19.jpg", nombre: "Toalla Microfibra Deportiva", precio: "COP 18.000", anterior: null },
    { img: "imagenes/productos/producto20.jpg", nombre: "Pulsera Deportiva SmartFit", precio: "COP 110.000", anterior: "COP 150.000" },
    { img: "imagenes/productos/producto21.jpg", nombre: "Balón Baloncesto Outdoor", precio: "COP 70.000", anterior: null },
    { img: "imagenes/productos/producto22.jpg", nombre: "Camiseta Running Mujer Ultralight", precio: "COP 52.000", anterior: null },
    { img: "imagenes/productos/producto23.jpg", nombre: "Mancuernas Hexagonales 5KG", precio: "COP 120.000", anterior: "COP 150.000" },
    { img: "imagenes/productos/producto24.jpg", nombre: "Saco Deportivo Cortaviento", precio: "COP 89.000", anterior: "COP 120.000" },
    { img: "imagenes/productos/producto25.jpg", nombre: "Tennis Urbanos Classic", precio: "COP 140.000", anterior: "COP 190.000" },
    { img: "imagenes/productos/producto26.jpg", nombre: "Protector Bucal Boxeo", precio: "COP 12.000", anterior: null },
    { img: "imagenes/productos/producto27.jpg", nombre: "Tennis Trail Running GripMax", precio: "COP 290.000", anterior: "COP 350.000" },
    { img: "imagenes/productos/producto28.jpg", nombre: "Brazalete Porta Celular", precio: "COP 25.000", anterior: null },
    { img: "imagenes/productos/producto29.jpg", nombre: "Set Conos Entrenamiento 10pcs", precio: "COP 32.000", anterior: null },
    { img: "imagenes/productos/producto30.jpg", nombre: "Pesas Disco 2.5KG", precio: "COP 40.000", anterior: "COP 55.000" }
];
function mezclar(array) {
    return array.sort(() => Math.random() - 0.5);
}

function mostrarProductos() {
    const contenedor = document.getElementById("grid-productos");

    // mezclamos productos
    const productosMezclados = mezclar(productos);

    // toma máximo 10
    const seleccion = productosMezclados.slice(0, 10);

    contenedor.innerHTML = "";

    seleccion.forEach(p => {
        contenedor.innerHTML += `
            <div class="producto-card">
                <img src="${p.img}" alt="${p.nombre}">
                <h3>${p.nombre}</h3>
                <p class="precio-actual">${p.precio}
                    ${p.anterior ? `<span class="precio-anterior">${p.anterior}</span>` : ""}
                </p>
                <div class="rating">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-regular fa-star"></i>
                </div>
                <i class="fa-solid fa-lock lock-icon"></i>
            </div>
        `;
    });
}

window.addEventListener("load", mostrarProductos);

const testimonios = [
    {
        nombre: "Mateo Fernández",
        tipo: "Comprador",
        texto: "En Runwin encontré todo lo que necesitaba para mis entrenamientos: ropa ligera, zapatillas cómodas y accesorios útiles. La compra fue rápida y segura.",
        estrellas: 5,
        img: "imagenes/valoraciones/hombre1.jpg"
    },
    {
        nombre: "Felipe Portilla",
        tipo: "Comprador recurrente",
        texto: "Compré una gorra en Runwin porque siempre terminaba con el sol en la cara cuando salía a correr. La calidad me sorprendió bastante: es ligera, transpirable y no se mueve con el viento.",
        estrellas: 5,
        img: "imagenes/valoraciones/hombre2.jpg"
    },
    {
        nombre: "Sebastián Yraruro",
        tipo: "Comprador",
        texto: "Decidí comprarle a mi hijo sus primeros zapatos deportivos en Runwin. Los materiales son resistentes y la talla fue perfecta gracias a la guía de medidas.",
        estrellas: 5,
        img: "imagenes/valoraciones/hombre3.jpg"
    },
    {
        nombre: "Isabella Rojas",
        tipo: "Compradora frecuente",
        texto: "Soy corredora amateur y necesitaba ropa que no rozara ni pesara. En Runwin encontré prendas realmente cómodas y frescas. Superó mis expectativas.",
        estrellas: 4,
        img: "imagenes/valoraciones/mujer1.jpg"
    },
    {
        nombre: "Julián Parra",
        tipo: "Comprador",
        texto: "Compré un reloj deportivo con GPS y funciona excelente. La batería dura muchísimo y la interfaz es fácil de usar. Muy recomendado.",
        estrellas: 5,
        img: "imagenes/valoraciones/hombre4.jpg"
    },
    {
        nombre: "Sofía Delgado",
        tipo: "Compradora",
        texto: "Me encantaron las mallas deportivas. El envío fue rápido, la calidad espectacular y el color exactamente igual a la imagen.",
        estrellas: 5,
        img: "imagenes/valoraciones/mujer2.jpg"
    },
    {
        nombre: "Oscar Rodríguez",
        tipo: "Comprador recurrente",
        texto: "Ya he comprado varias veces y nunca me han fallado. La relación calidad-precio es muy buena y la atención al cliente siempre responde rápido.",
        estrellas: 4,
        img: "imagenes/valoraciones/hombre5.jpg"
    },
    {
        nombre: "Mariana López",
        tipo: "Compradora",
        texto: "Las bandas de resistencia que compré tienen muy buena elasticidad y material firme. Son perfectas para mis rutinas en casa.",
        estrellas: 5,
        img: "imagenes/valoraciones/mujer3.jpg"
    },
    {
        nombre: "Andrés Ceballos",
        tipo: "Comprador",
        texto: "Necesitaba un bolso deportivo espacioso y liviano. El que compré aquí es excelente, muy resistente y con bolsillos bien distribuidos.",
        estrellas: 5,
        img: "imagenes/valoraciones/hombre6.jpg"
    },
    {
        nombre: "Camila Torres",
        tipo: "Compradora frecuente",
        texto: "Las camisetas térmicas son lo mejor que he comprado. Son suaves, cómodas y mantienen la temperatura durante las carreras en clima frío.",
        estrellas: 5,
        img: "imagenes/valoraciones/mujer4.jpg"
    },
    {
        nombre: "Mauricio Herrera",
        tipo: "Comprador",
        texto: "El servicio fue impecable. El pedido llegó incluso antes de lo esperado y todo venía muy bien empaquetado.",
        estrellas: 5,
        img: "imagenes/valoraciones/hombre7.jpg"
    },
    {
        nombre: "Lina González",
        tipo: "Compradora",
        texto: "Compré unos audífonos deportivos y el sonido es increíble. Se ajustan bien y no se caen al correr. Perfectos para mis entrenamientos.",
        estrellas: 5,
        img: "imagenes/valoraciones/mujer5.jpg"
    }
];

document.addEventListener("DOMContentLoaded", function () {
    mostrarProductos();
    iniciarCarruselTestimonios();
});

function iniciarCarruselTestimonios() {
    let indice = 0;
    const porPagina = 3;
    const contenedor = document.getElementById("contenedor-testimonios");

    function mostrarTestimonios() {
        contenedor.innerHTML = "";
        const inicio = indice * porPagina;
        const pagina = testimonios.slice(inicio, inicio + porPagina);

        pagina.forEach(t => {
            contenedor.innerHTML += `
                <div class="testimonio-card">
                    <p class="texto">"${t.texto}"</p>
                    <div class="perfil">
                        <img src="${t.img}" class="foto">
                        <div>
                            <h4>${t.nombre}</h4>
                            <span>${t.tipo}</span>
                        </div>
                    </div>
                    <div class="estrellas">⭐️⭐️⭐️⭐️⭐️</div>
                </div>`;
        });
    }

    mostrarTestimonios();

    document.getElementById("btn-next").onclick = () => {
        const total = Math.ceil(testimonios.length / porPagina);
        if (indice < total - 1) { indice++; mostrarTestimonios(); }
    };

    document.getElementById("btn-prev").onclick = () => {
        if (indice > 0) { indice--; mostrarTestimonios(); }
    };
}

function mostrarToast(mensaje, tipo = "exito") {
    const toast = document.createElement("div");

    toast.className = tipo === "error" ? "toast error" : "toast";
    toast.textContent = mensaje;

    document.body.appendChild(toast);

    // Quitar después de 3 segundos
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

const btn = document.getElementById("btnSuscribir");

if (btn) {
    btn.addEventListener("click", function () {
        const email = document.getElementById("emailInput").value.trim();

        if (email === "" || !email.includes("@") || !email.includes(".")) {
            mostrarToast("Correo inválido. Intenta de nuevo.", "error");
            return;
        }

        mostrarToast("¡Gracias por suscribirte! 🎉");

        document.getElementById("emailInput").value = "";
    });
}

