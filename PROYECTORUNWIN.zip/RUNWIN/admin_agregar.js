
const inputImagen = document.getElementById("imagen");
const previewImg = document.getElementById("previewImg");

inputImagen.addEventListener("change", () => {
    const archivo = inputImagen.files[0];
    if (archivo) {
        previewImg.src = URL.createObjectURL(archivo);
    } else {
        previewImg.src = "imagenes/placeholder.png";
    }
});


//  AGREGAR PRODUCTO
const btnAgregar = document.getElementById("btnAgregar");

btnAgregar.addEventListener("click", async () => {

    const nombre = document.getElementById("nombre").value.trim();
    const precio = document.getElementById("precio").value.trim();
    const categoria = document.getElementById("categoriaId").value.trim();
    const descripcion = document.getElementById("descripcion").value.trim();
    const imagen = inputImagen.files[0];

    // Validación de campos vacíos
    if (!nombre || !precio || !categoria || !descripcion) {
        alert("⚠ Por favor completa todos los campos.");
        return;
    }

    const formData = new FormData();
    formData.append("nombre", nombre);
    formData.append("precio", precio);
    formData.append("categoria", categoria);
    formData.append("descripcion", descripcion);

    if (imagen) {
        formData.append("imagen", imagen); 
    }

    try {
        const response = await fetch("http://localhost:8081/api/productos", {
            method: "POST",
            body: formData,
        });

        if (!response.ok) {
            const txt = await response.text();
            console.error("Servidor respondió:", txt);
            throw new Error("Error al guardar producto");
        }

        alert("✅ Producto agregado exitosamente");

        // RESET FORMULARIO
        document.getElementById("nombre").value = "";
        document.getElementById("precio").value = "";
        document.getElementById("categoriaId").value = "";
        document.getElementById("descripcion").value = "";
        inputImagen.value = "";
        previewImg.src = "imagenes/placeholder.png";

    } catch (error) {
        console.error("❌ ERROR:", error);
        alert("❌ No se pudo agregar el producto.");
    }
});
    // Botón cerrar sesión
    document.getElementById("btnSalir").addEventListener("click", () => {
        localStorage.removeItem("usuario");
        window.location.href = "inicio_sesion.html";
    });