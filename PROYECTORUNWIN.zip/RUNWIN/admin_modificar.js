function getImagenSrc(nombre) {
    if (!nombre) {
        return "imagenes/placeholder.png";
    }
    if (/^\d/.test(nombre)) {
        return `http://localhost:8081/uploads/${nombre}`;
    }
    return nombre;
}

document.addEventListener("DOMContentLoaded", () => {
    cargarListaProductos();

    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");

    if (id) cargarProducto(id);
});


async function cargarProducto(id) {
    try {
        const response = await fetch(`http://localhost:8081/api/productos/${id}`);
        if (!response.ok) throw new Error("No se pudo cargar el producto");

        const prod = await response.json();

        document.getElementById("prodNombre").textContent = prod.nombre;
        document.getElementById("prodPrecio").textContent = `Precio = ${prod.precio} COP`;

        document.getElementById("previewImg").src = getImagenSrc(prod.imagen);

        document.getElementById("nuevoNombre").value = prod.nombre;
        document.getElementById("nuevoPrecio").value = prod.precio;

    } catch (error) {
        console.error(error);
        alert("Error cargando producto.");
    }
}


document.getElementById("editForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");

    const formData = new FormData();
    formData.append("nombre", document.getElementById("nuevoNombre").value);
    formData.append("precio", document.getElementById("nuevoPrecio").value);

    const imagen = document.getElementById("nuevaImagen").files[0];
    if (imagen) formData.append("imagen", imagen);

    try {
        const response = await fetch(`http://localhost:8081/api/productos/${id}`, {
            method: "PUT",
            body: formData
        });

        if (!response.ok) throw new Error();

        alert("Producto actualizado ✔");

    } catch (e) {
        alert("❌ Error al actualizar producto");
        console.error(e);
    }
});


// ===== Cargar lista de productos =====
async function cargarListaProductos() {
    const select = document.getElementById("selectorProducto");

    const resp = await fetch("http://localhost:8081/api/productos");
    const productos = await resp.json();

    productos.forEach(p => {
        const opt = document.createElement("option");
        opt.value = p.id;
        opt.textContent = p.nombre;
        select.appendChild(opt);
    });

    select.addEventListener("change", () => {
        if (select.value !== "") {
            window.location.href = `admin_modificar.html?id=${select.value}`;
        }
    });
}
    // Botón cerrar sesión
    document.getElementById("btnSalir").addEventListener("click", () => {
        localStorage.removeItem("usuario");
        window.location.href = "inicio_sesion.html";
    });