function obtenerUsuario() {
    try {
        const u = JSON.parse(localStorage.getItem("usuario"));
        if (!u || !u.id) return null;
        return u;
    } catch (e) {
        return null;
    }
}
document.addEventListener("DOMContentLoaded", cargarProductosNino);

async function cargarProductosNino() {

    const contenedor = document.getElementById("productos-nino");

    try {
      
        const apiUrl = "http://localhost:8081/api/productos/categoria/3";

        const respuesta = await fetch(apiUrl);

        if (!respuesta.ok) {
            throw new Error(`Error ${respuesta.status}: No se pudieron cargar los productos de Niño.`);
        }

        const productos = await respuesta.json();

        if (productos.length === 0) {
            contenedor.innerHTML = `
                <p class="text-gray-500 p-4 text-center">
                    No hay productos disponibles para esta categoría.
                </p>`;
            return;
        }

        contenedor.innerHTML = "";

        productos.forEach(prod => {
            const card = document.createElement("div");
            card.classList.add("producto-card");

                        if (!prod.imagen) {
                imagenSrc = "https://placehold.co/400x400?text=Sin+Imagen";
            }
            // Si empieza por número, viene del backend
            else if (/^\d/.test(prod.imagen)) {
                imagenSrc = `http://localhost:8081/uploads/${prod.imagen}`;
            }
            // Si no empieza por número, es del frontend
            else {
                imagenSrc = `${prod.imagen}`;
            }


            card.innerHTML = `
                <img class="producto-img" src="${imagenSrc}" alt="${prod.nombre}">

                <h3 class="producto-nombre">${prod.nombre}</h3>

                <p class="producto-precio">
                    COP ${prod.precio ? prod.precio.toLocaleString("es-CO") : "N/A"}
                </p>

                <div class="producto-botones">

                    <button class="btn-agregar" onclick="agregarAlCarrito(${prod.id})">
                        🛒 Agregar al carrito
                    </button>

                    <button class="btn-deseos" onclick="agregarWishlist(${prod.id})">
                        🤍 Deseos
                    </button>

                </div>
            `;

            contenedor.appendChild(card);
        });

    } catch (error) {
        contenedor.innerHTML = `
            <p class="text-red-600 p-4 text-center">
                🛑 Error al cargar los productos.<br>
                Mensaje: ${error.message}
            </p>`;
        console.error("Error al cargar productos de Niño:", error);
    }
}


function agregarAlCarrito(productoId) {
    const usuario = obtenerUsuario();

    if (!usuario) {
        alert("Debes iniciar sesión para agregar productos 🛒");
        window.location.href = "inicio_sesion.html";
        return;
    }

    fetch(`http://localhost:8081/api/carrito/${usuario.id}/agregar/${productoId}`, {
        method: "POST"
    })
    .then(r => {
        if (r.ok) {
            alert("Producto agregado al carrito 🛒");
        } else {
            alert("Error al agregar producto");
        }
    })
    .catch(err => console.error(err));
}


function agregarWishlist(productoId) {

    const usuario = obtenerUsuario();

    if (!usuario) {
        alert("Debes iniciar sesión para usar la lista de deseos 🤍");
        window.location.href = "inicio_sesion.html";
        return;
    }

    fetch("http://localhost:8081/api/wishlist", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            usuarioId: usuario.id,
            productoId: productoId
        })
    })
    .then(r => {
        if (r.ok) {
            alert("Producto agregado a tu lista de deseos 🤍");
        } else {
            alert("No se pudo agregar a la lista 😢");
        }
    })
    .catch(err => console.error("Error wishlist:", err));
}
