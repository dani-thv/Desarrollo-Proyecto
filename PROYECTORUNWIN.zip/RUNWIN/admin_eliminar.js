function getImagenSrc(nombre) {
    if (!nombre) return "imagenes/placeholder.png";

    if (/^\d/.test(nombre)) {
        return `http://localhost:8081/uploads/${nombre}`;
    }
    return nombre;
}

document.addEventListener("DOMContentLoaded", () => {
    cargarProductos();
});

async function cargarProductos() {
    const select = document.getElementById("selectorProducto");

    const resp = await fetch("http://localhost:8081/api/productos");
    const productos = await resp.json();

    productos.forEach(p => {
        const opt = document.createElement("option");
        opt.value = p.id;
        opt.textContent = p.nombre;
        select.appendChild(opt);
    });

    select.addEventListener("change", () => {
        if (select.value !== "") {
            cargarProducto(select.value);
        }
    });
}


async function cargarProducto(id) {
    const resp = await fetch(`http://localhost:8081/api/productos/${id}`);
    const prod = await resp.json();

    document.getElementById("previewImg").src = getImagenSrc(prod.imagen);
    document.getElementById("prodNombre").textContent = prod.nombre;
    document.getElementById("prodPrecio").textContent = `Precio = ${prod.precio} COP`;

    document.getElementById("btnEliminar").disabled = false;

    document.getElementById("btnEliminar").onclick = () => confirmarEliminar(id);
}

async function confirmarEliminar(id) {
    if (!confirm("¿Seguro que deseas eliminar este producto?")) return;

    const resp = await fetch(`http://localhost:8081/api/productos/${id}`, {
        method: "DELETE"
    });

    if (resp.ok) {
        alert("Producto eliminado ✔");

        location.reload();
    } else {
        alert("Error al eliminar ❌");
    }
}
    // Botón cerrar sesión
    document.getElementById("btnSalir").addEventListener("click", () => {
        localStorage.removeItem("usuario");
        window.location.href = "inicio_sesion.html";
    });