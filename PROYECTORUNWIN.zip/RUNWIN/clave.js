document.getElementById("btnRecuperar").addEventListener("click", function (e) {
    e.preventDefault();

    const nombre = document.getElementById("nombre").value.trim();
    const correo = document.getElementById("correo").value.trim();

    if (nombre === "" || correo === "" || !correo.includes("@") || !correo.includes(".")) {
        mostrarToast("Por favor completa todos los campos correctamente.", "error");
        return;
    }

    mostrarToast("Si el correo existe, enviaremos un enlace a tu email 📩", "exito");

    document.getElementById("recuperarForm").reset();
});

function mostrarToast(mensaje, tipo = "exito") {
    const toast = document.createElement("div");

    toast.className = tipo === "error" ? "toast error" : "toast";
    toast.textContent = mensaje;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 3000);
}
