document.addEventListener("DOMContentLoaded", async () => {

    const usuario = JSON.parse(localStorage.getItem("usuario"));

    if (!usuario) {
        window.location.href = "inicio_sesion.html";
        return;
    }


    document.getElementById("nombre-usuario").textContent = usuario.nombre;
    document.getElementById("correo-usuario").textContent = usuario.correo;
    document.querySelector(".rol-usuario").textContent = usuario.rol.toUpperCase();


    const fotoPanel = document.getElementById("foto-usuario");

    if (usuario.foto && usuario.foto !== "null" && usuario.foto.trim() !== "") {

        if (usuario.foto.startsWith("user_")) {
            fotoPanel.src = "http://localhost:8081/uploads/" + usuario.foto;
        } else {
            fotoPanel.src = usuario.foto;
        }

    } else {
        fotoPanel.src = "";
    }

    document.getElementById("dir-detalle").textContent = usuario.direccion;
    document.getElementById("telefono-usuario").textContent = usuario.telefono;

    // FUNCIÓN PARA FORMATEAR FECHA

    function formatearFecha(fechaISO) {
        const fecha = new Date(fechaISO);
        return fecha.toLocaleDateString("es-CO", {
            day: "2-digit",
            month: "short",
            year: "numeric",
            timeZone: "UTC"
        });
    }

    // HISTORIAL DE COMPRAS

    const tbody = document.getElementById("tabla-historial-body");
    tbody.innerHTML = "";

    try {
        const resp = await fetch(`http://localhost:8081/api/pedidos/usuario/${usuario.id}`);

        if (!resp.ok) throw new Error("No se pudo obtener el historial");

        const pedidos = await resp.json();

        if (pedidos.length === 0) {
            tbody.innerHTML = `
                <tr><td colspan="5" style="text-align:center;padding:12px;">No tienes pedidos aún</td></tr>
            `;
        } else {


            let contador = 1;

            pedidos.forEach(p => {
                const fila = document.createElement("tr");

                fila.innerHTML = `
                    <td>#${contador++}</td>  
                    <td>${formatearFecha(p.fecha)}</td>
                    <td>COP ${Number(p.total).toLocaleString("es-CO")}</td>
                    <td>${p.estado}</td>
                    <td><a href="detalle_pedido.html?id=${p.id}" class="ver-detalles">Ver detalles</a></td>
                `;

                tbody.appendChild(fila);
            });
        }

    } catch (err) {
        console.error(err);
        tbody.innerHTML = `
            <tr><td colspan="5" style="text-align:center; padding:12px; color:red;">
                Error cargando historial
            </td></tr>
        `;
    }

    // CERRAR SESIÓN

    document.getElementById("cerrar-sesion").addEventListener("click", () => {
        localStorage.removeItem("usuario");
        window.location.href = "inicio_sesion.html";
    });

});
