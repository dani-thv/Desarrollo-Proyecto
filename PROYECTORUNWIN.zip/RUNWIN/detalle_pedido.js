
function getImagenSrc(nombre) {

    if (!nombre) {
        return "https://placehold.co/400x400?text=Sin+Imagen";
    }

    // Si empieza por un número → imagen subida guardada en /uploads/
    if (/^\d/.test(nombre)) {
        return `http://localhost:8081/uploads/${nombre}`;
    }

    // Si no empieza por número → imagen vieja del frontend
    return `${nombre}`;
}document.addEventListener("DOMContentLoaded", async () => {

    const params = new URLSearchParams(window.location.search);
    const pedidoId = Number(params.get("id"));

    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (!usuario) {
        window.location.href = "inicio_sesion.html";
        return;
    }

    if (!pedidoId) {
        alert("Pedido no encontrado");
        window.location.href = "historial_compras.html";
        return;
    }

    try {
        // Pedir todos los pedidos del usuario
        const respHist = await fetch(`http://localhost:8081/api/pedidos/usuario/${usuario.id}`);
        const listaPedidos = await respHist.json();

        // Buscar la posición del pedido actual
        const indexVirtual = listaPedidos.findIndex(p => p.id === pedidoId) + 1;

        // cargar el pedido real
        const respuesta = await fetch(`http://localhost:8081/api/pedidos/${pedidoId}`);
        if (!respuesta.ok) {
            alert("No se pudo cargar el pedido");
            return;
        }

        const pedido = await respuesta.json();

        
        document.getElementById("titulo-pedido").textContent = `Pedido #${indexVirtual}`;

        // Fecha
        const fecha = new Date(pedido.fecha);
        document.getElementById("detalle-fecha").textContent =
            fecha.toLocaleDateString("es-CO", { timeZone: "UTC" });

        // Total y estado
        document.getElementById("detalle-total").textContent =
            "COP " + Number(pedido.total).toLocaleString("es-CO");

        document.getElementById("detalle-estado").textContent = pedido.estado;

        // Tabla de productos
        const tabla = document.getElementById("tabla-productos");
        tabla.innerHTML = "";

        for (const item of pedido.items) {

            const resProd = await fetch(`http://localhost:8081/api/productos/${item.productoId}`);
            const producto = await resProd.json();

            const imagen = getImagenSrc(producto.imagen);
            const subtotal = item.cantidad * item.precioUnitario;

            tabla.innerHTML += `
                <tr>
                    <td>
                        <div class="producto-detalle">
                            <img src="${imagen}" class="producto-img-detalle">
                            <span>${producto.nombre}</span>
                        </div>
                    </td>
                    <td>${item.cantidad}</td>
                    <td>COP ${item.precioUnitario.toLocaleString("es-CO")}</td>
                    <td>COP ${subtotal.toLocaleString("es-CO")}</td>
                </tr>
            `;
        }

    } catch (error) {
        console.error(error);
        alert("Error al cargar la información del pedido.");
    }
});

// Cerrar sesión
document.getElementById("cerrar-sesion").addEventListener("click", () => {
    localStorage.removeItem("usuario");
    window.location.href = "inicio_sesion.html";
});
