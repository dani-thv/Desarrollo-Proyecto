package com.example.runwin_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunwinBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(RunwinBackendApplication.class, args);
	}

}
