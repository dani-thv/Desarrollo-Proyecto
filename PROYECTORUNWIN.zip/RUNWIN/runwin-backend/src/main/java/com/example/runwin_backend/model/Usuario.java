package com.example.runwin_backend.model;
import jakarta.persistence.*;
import lombok.Data;
@Data
@Entity
@Table(name = "usuarios")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String nombre;

    @Column(unique = true)
    private String correo;

    private String contrasena;

    private String rol;

    private String direccion;

    private String telefono;

    private String foto; // url de imagen
}
