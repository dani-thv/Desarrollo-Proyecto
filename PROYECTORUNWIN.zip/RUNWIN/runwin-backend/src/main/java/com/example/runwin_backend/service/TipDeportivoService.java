package com.example.runwin_backend.service;

import com.example.runwin_backend.dto.TipDTO;
import com.example.runwin_backend.repository.TipDeportivoRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TipDeportivoService {

    private final TipDeportivoRepository tipRepo;

    public TipDeportivoService(TipDeportivoRepository tipRepo) {
        this.tipRepo = tipRepo;
    }

    public List<TipDTO> obtenerTresTips() {

        List<Object[]> data = tipRepo.obtenerTresTipsAleatorios();
        List<TipDTO> lista = new ArrayList<>();

        for (Object[] row : data) {
            lista.add(new TipDTO(
                    (Integer) row[0],
                    (String) row[1],
                    (String) row[2],
                    (String) row[3],
                    (String) row[4],
                    ((Number) row[5]).intValue()
            ));
        }

        return lista;
    }
}
