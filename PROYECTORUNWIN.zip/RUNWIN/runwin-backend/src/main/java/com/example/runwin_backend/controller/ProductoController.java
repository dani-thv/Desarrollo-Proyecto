package com.example.runwin_backend.controller;

import com.example.runwin_backend.dto.ProductoDescuentoDTO;
import com.example.runwin_backend.model.Producto;
import com.example.runwin_backend.service.ProductoService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/productos")

public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    // Obtener producto por ID
    @GetMapping("/{id}")
    public Producto obtenerProducto(@PathVariable Integer id) {
        return productoService.obtenerProducto(id);
    }

    // Obtener productos por categoría
    @GetMapping("/categoria/{categoriaId}")
    public List<?> obtenerPorCategoria(@PathVariable Integer categoriaId) {

        // Si la categoría es 6 -> aplicar JOIN con tabla descuentos
        if (categoriaId == 6) {
            return productoService.obtenerProductosConDescuento(categoriaId);
        }

        // Categorías normales (1, 2, 3, ...)
        return productoService.obtenerProductosNormales(categoriaId);
    }

    @GetMapping
    public List<Producto> listarTodos() {
        return productoService.listarTodos();
    }

    @PostMapping
    public Producto crearProducto(
            @RequestParam("nombre") String nombre,
            @RequestParam("precio") Integer precio,
            @RequestParam("categoria") Integer categoriaId,
            @RequestParam("descripcion") String descripcion,
            @RequestParam(value = "imagen", required = false) MultipartFile imagen
    ) throws IOException {
        return productoService.crearProducto(nombre, precio, categoriaId, descripcion, imagen);
    }

    @PutMapping("/{id}")
    public Producto actualizarProducto(
            @PathVariable Integer id,
            @RequestParam("nombre") String nombre,
            @RequestParam("precio") Integer precio,
            @RequestParam(value = "imagen", required = false) MultipartFile imagen
    ) throws IOException {

        return productoService.actualizarProducto(id, nombre, precio, imagen);
    }
    @DeleteMapping("/{id}")
    public void eliminarProducto(@PathVariable Integer id) {
        productoService.eliminarProducto(id);
    }
    @GetMapping("/buscar")
    public List<Producto> buscarProductos(@RequestParam String nombre) {
        return productoService.buscarPorNombre(nombre);
    }



}
