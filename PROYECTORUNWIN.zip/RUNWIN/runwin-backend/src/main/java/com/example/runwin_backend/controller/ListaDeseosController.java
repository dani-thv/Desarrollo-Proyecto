package com.example.runwin_backend.controller;

import com.example.runwin_backend.model.ListaDeseos;
import com.example.runwin_backend.service.ListaDeseosService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/wishlist")

public class ListaDeseosController {

    private final ListaDeseosService service;

    public ListaDeseosController(ListaDeseosService service) {
        this.service = service;
    }

    // Obtener wishlist de un usuario
    @GetMapping("/{usuarioId}")
    public List<ListaDeseos> obtenerLista(@PathVariable Integer usuarioId) {
        return service.obtenerPorUsuario(usuarioId);
    }

    // Agregar producto a la wishlist
    @PostMapping
    public ListaDeseos agregar(@RequestBody ListaDeseos item) {
        return service.agregar(item);
    }

    // Eliminar un producto de la wishlist
    @DeleteMapping("/{usuarioId}/{productoId}")
    public ResponseEntity<?> eliminar(
            @PathVariable Integer usuarioId,
            @PathVariable Integer productoId) {

        boolean eliminado = service.eliminar(usuarioId, productoId);

        if (!eliminado) {
            return ResponseEntity.status(404).body("No existe en la wishlist");
        }

        return ResponseEntity.ok("Eliminado");
    }

}

