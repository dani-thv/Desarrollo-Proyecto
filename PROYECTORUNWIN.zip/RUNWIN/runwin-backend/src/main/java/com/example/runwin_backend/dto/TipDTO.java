package com.example.runwin_backend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TipDTO {
    private Integer id;
    private String titulo;
    private String contenido;
    private String productoNombre;
    private String productoImagen;
    private Integer productoPrecio;
}
