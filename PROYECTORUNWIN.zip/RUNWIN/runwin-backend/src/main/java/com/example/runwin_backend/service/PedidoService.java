package com.example.runwin_backend.service;

import com.example.runwin_backend.model.Pedido;
import com.example.runwin_backend.model.PedidoItem;
import com.example.runwin_backend.repository.PedidoItemRepository;
import com.example.runwin_backend.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepo;

    @Autowired
    private PedidoItemRepository itemRepo;

    public Pedido crearPedido(Pedido pedido) {

        pedido.setFecha(LocalDate.now());
        pedido.setEstado("Procesado");

        if (pedido.getTotal() == null) {
            pedido.setTotal(0);
        }

        return pedidoRepo.save(pedido);
    }

    // Agregar item al pedido
    public PedidoItem agregarItem(PedidoItem item) {
        return itemRepo.save(item);
    }

    // Obtener pedido con sus items
    public Pedido obtenerPedidoConItems(Integer id) {

        Pedido pedido = pedidoRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        List<PedidoItem> items = itemRepo.findByPedidoId(id);
        pedido.setItems(items);

        return pedido;
    }

    // Historial por usuario
    public List<Pedido> listarPorUsuario(Integer usuarioId) {
        return pedidoRepo.findByUsuarioId(usuarioId);
    }

    // Listar todos los pedidos
    public List<Pedido> listarTodos() {
        return pedidoRepo.findAll();
    }
}
