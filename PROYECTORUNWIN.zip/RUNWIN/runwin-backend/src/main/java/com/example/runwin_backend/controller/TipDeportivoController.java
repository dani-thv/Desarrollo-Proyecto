package com.example.runwin_backend.controller;

import com.example.runwin_backend.service.TipDeportivoService;
import com.example.runwin_backend.dto.TipDTO;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/tips")
public class TipDeportivoController {

    private final TipDeportivoService tipService;

    public TipDeportivoController(TipDeportivoService tipService) {
        this.tipService = tipService;
    }

    @GetMapping("/aleatorios")
    public List<TipDTO> obtenerTresTips() {
        return tipService.obtenerTresTips();
    }
}
