package com.example.runwin_backend.service;

import com.example.runwin_backend.model.Carrito;
import com.example.runwin_backend.model.CarritoItem;
import com.example.runwin_backend.repository.CarritoItemRepository;
import com.example.runwin_backend.repository.CarritoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CarritoService {

    @Autowired
    private CarritoRepository carritoRepo;

    @Autowired
    private CarritoItemRepository itemRepo;

    public List<Map<String, Object>> obtenerItems(Integer usuarioId) {

        List<Object[]> filas = carritoRepo.obtenerCarritoConItems(usuarioId);
        List<Map<String, Object>> lista = new java.util.ArrayList<>();

        for (Object[] f : filas) {
            Map<String, Object> item = new java.util.HashMap<>();

            item.put("id", f[0]);              // item_id
            item.put("productoId", f[1]);
            item.put("nombre", f[2]);

            item.put("precioOriginal", f[3]);  // p.precio
            item.put("porcentaje", f[4]);      // descuento
            item.put("precioFinal", f[5]);     // precio con descuento

            item.put("cantidad", f[6]);
            item.put("subtotal", f[7]);

            item.put("imagen", f[8]);

            lista.add(item);
        }

        return lista;
    }

    // Agregar item
    public CarritoItem agregarItem(Integer usuarioId, Integer productoId) {

        Carrito carrito = carritoRepo.findByUsuarioId(usuarioId);

        if (carrito == null) {
            carrito = new Carrito();
            carrito.setUsuarioId(usuarioId);
            carrito = carritoRepo.save(carrito);
        }

        CarritoItem item = new CarritoItem();
        item.setCarritoId(carrito.getId());
        item.setProductoId(productoId);
        item.setCantidad(1);
        return itemRepo.save(item);
    }

    // Actualizar cantidad
    public CarritoItem actualizarCantidad(Integer itemId, Integer cantidad) {
        CarritoItem item = itemRepo.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Item no encontrado"));

        item.setCantidad(cantidad);
        return itemRepo.save(item);
    }

    // Eliminar item
    public void eliminarItem(Integer itemId) {
        itemRepo.deleteById(itemId);
    }

    // 🚀 Vaciar carrito correctamente
    public void vaciarCarrito(Integer usuarioId) {

        Carrito carrito = carritoRepo.findByUsuarioId(usuarioId);

        if (carrito != null) {

            // borrar items
            itemRepo.deleteByCarritoId(carrito.getId());

            // borrar carrito
            carritoRepo.delete(carrito);
        }
    }
}
