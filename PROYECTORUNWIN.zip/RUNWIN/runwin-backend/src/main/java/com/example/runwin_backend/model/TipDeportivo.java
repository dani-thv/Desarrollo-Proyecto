package com.example.runwin_backend.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "tips_deportivos")
public class TipDeportivo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String titulo;

    @Column(columnDefinition = "text")
    private String contenido;

    @Column(name = "producto_id")
    private Integer productoId;
}
