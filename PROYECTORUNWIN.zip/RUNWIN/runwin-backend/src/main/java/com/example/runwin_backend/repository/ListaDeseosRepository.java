package com.example.runwin_backend.repository;

import com.example.runwin_backend.model.ListaDeseos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.repository.query.Param;

import java.util.List;

@Repository
public interface ListaDeseosRepository extends JpaRepository<ListaDeseos, Integer> {

    List<ListaDeseos> findByUsuarioId(Integer usuarioId);

    boolean existsByUsuarioIdAndProductoId(Integer usuarioId, Integer productoId);

    void deleteByUsuarioIdAndProductoId(Integer usuarioId, Integer productoId);

    @Transactional
    @Modifying
    @Query("DELETE FROM ListaDeseos l WHERE l.usuarioId = :usuarioId AND l.productoId = :productoId")
    void eliminarWishlist(@Param("usuarioId") Integer usuarioId,
                          @Param("productoId") Integer productoId);

}


