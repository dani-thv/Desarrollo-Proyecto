package com.example.runwin_backend.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "productos")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String nombre;

    private Integer precio;

    private String descripcion;

    @Column(name = "categoria_id")
    private Integer categoriaId;

    private String imagen;

    @Column(nullable = false)
    private Boolean activo = true;
}
