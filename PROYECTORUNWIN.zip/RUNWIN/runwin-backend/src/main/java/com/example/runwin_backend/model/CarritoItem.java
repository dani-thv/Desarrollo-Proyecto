package com.example.runwin_backend.model;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "carrito_items")
@Data
public class CarritoItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "carrito_id")
    private Integer carritoId;

    @Column(name = "producto_id")
    private Integer productoId;

    @Column(nullable = false)
    private Integer cantidad;
}
