package com.example.runwin_backend.repository;

import com.example.runwin_backend.model.Descuento;   // ESTE ES EL BUENO
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DescuentoRepository extends JpaRepository<Descuento, Integer> {
    Optional<Descuento> findByProductoId(Integer productoId);
}
