package com.example.runwin_backend.repository;

import com.example.runwin_backend.model.Carrito;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;

public interface CarritoRepository extends JpaRepository<Carrito, Integer> {

    Carrito findByUsuarioId(Integer usuarioId);

    @Query(value = """
        SELECT 
            ci.id AS item_id,
            p.id AS producto_id,
            p.nombre,
            p.precio AS precio_original,
            COALESCE(d.porcentaje, 0) AS porcentaje,
            (p.precio - (p.precio * COALESCE(d.porcentaje, 0) / 100)) AS precio_final,
            ci.cantidad,
            ((p.precio - (p.precio * COALESCE(d.porcentaje, 0) / 100)) * ci.cantidad) AS subtotal,
            p.imagen
        FROM carrito c
        JOIN carrito_items ci ON c.id = ci.carrito_id
        JOIN productos p ON p.id = ci.producto_id
        LEFT JOIN descuentos d ON d.producto_id = p.id
        WHERE c.usuario_id = ?1
        """,
            nativeQuery = true)
    List<Object[]> obtenerCarritoConItems(Integer usuarioId);


}
