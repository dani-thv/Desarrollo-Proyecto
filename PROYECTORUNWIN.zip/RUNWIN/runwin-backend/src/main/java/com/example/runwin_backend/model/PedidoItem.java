package com.example.runwin_backend.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "pedido_items")
public class PedidoItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "pedido_id")
    private Integer pedidoId;

    @Column(name = "producto_id")
    private Integer productoId;

    private Integer cantidad;

    @Column(name = "precio_unitario")
    private Integer precioUnitario;

    // 🔥 RELACIÓN CORRECTA CON PEDIDO (obligatoria para Hibernate)
    @ManyToOne
    @JoinColumn(name = "pedido_id", insertable = false, updatable = false)
    @JsonIgnore
    private Pedido pedido;
}
