package com.example.runwin_backend.controller;

import com.example.runwin_backend.model.Usuario;
import com.example.runwin_backend.service.UsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // Registro
    @PostMapping("/registro")
    public Usuario registrar(@RequestBody Usuario usuario) {
        return usuarioService.registrar(usuario);
    }

    // Login
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Usuario datos) {
        Usuario usuario = usuarioService.login(datos.getCorreo(), datos.getContrasena());

        if (usuario == null) {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body("{\"error\":\"Credenciales incorrectas\"}");
        }

        return ResponseEntity.ok(usuario);
    }

    @PutMapping("/actualizar")
    public Usuario actualizar(@RequestBody Usuario usuario) {
        return usuarioService.actualizarUsuario(usuario);
    }
    @PutMapping("/actualizarFoto")
    public Usuario actualizarFoto(
            @RequestParam("id") Integer id,
            @RequestParam("nombre") String nombre,
            @RequestParam("direccion") String direccion,
            @RequestParam("correo") String correo,
            @RequestParam("telefono") String telefono,
            @RequestParam(value = "contrasena", required = false) String contrasena,
            @RequestParam(value = "foto", required = false) MultipartFile foto
    ) throws IOException {

        return usuarioService.actualizarFoto(id, nombre, direccion, correo, telefono, contrasena, foto);
    }

    @GetMapping
    public List<Usuario> listarTodos() {
        return usuarioService.listarTodos();
    }


}
