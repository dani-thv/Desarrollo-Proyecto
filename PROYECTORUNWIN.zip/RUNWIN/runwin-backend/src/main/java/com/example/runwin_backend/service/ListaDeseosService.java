package com.example.runwin_backend.service;

import com.example.runwin_backend.model.ListaDeseos;
import com.example.runwin_backend.repository.ListaDeseosRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ListaDeseosService {

    private final ListaDeseosRepository repo;

    public ListaDeseosService(ListaDeseosRepository repo) {
        this.repo = repo;
    }

    public List<ListaDeseos> obtenerPorUsuario(Integer usuarioId) {
        return repo.findByUsuarioId(usuarioId);
    }

    public ListaDeseos agregar(ListaDeseos item) {
        return repo.save(item);
    }

    public boolean eliminar(Integer usuarioId, Integer productoId) {

        if (!repo.existsByUsuarioIdAndProductoId(usuarioId, productoId)) {
            return false;
        }

        repo.eliminarWishlist(usuarioId, productoId);
        return true;
    }

}

