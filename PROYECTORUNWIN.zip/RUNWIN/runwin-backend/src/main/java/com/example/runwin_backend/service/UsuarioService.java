package com.example.runwin_backend.service;

import com.example.runwin_backend.model.Usuario;
import com.example.runwin_backend.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    // REGISTRAR
    public Usuario registrar(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    // LOGIN
    public Usuario login(String correo, String contrasena) {
        return usuarioRepository.findAll()
                .stream()
                .filter(u -> u.getCorreo().equals(correo) &&
                        u.getContrasena().equals(contrasena))
                .findFirst()
                .orElse(null);
    }

    // OBTENER POR ID
    public Usuario obtenerPorId(Integer id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
    }

    // ACTUALIZAR USUARIO SIN FOTO
    public Usuario actualizarUsuario(Usuario datos) {

        Usuario usuario = obtenerPorId(datos.getId());

        if (datos.getNombre() != null) usuario.setNombre(datos.getNombre());
        if (datos.getCorreo() != null) usuario.setCorreo(datos.getCorreo());
        if (datos.getContrasena() != null && !datos.getContrasena().isEmpty())
            usuario.setContrasena(datos.getContrasena());
        if (datos.getDireccion() != null) usuario.setDireccion(datos.getDireccion());
        if (datos.getTelefono() != null) usuario.setTelefono(datos.getTelefono());
        if (datos.getRol() != null) usuario.setRol(datos.getRol());
        if (datos.getFoto() != null) usuario.setFoto(datos.getFoto());

        return usuarioRepository.save(usuario);
    }

    // ACTUALIZAR USUARIO + FOTO
    public Usuario actualizarFoto(Integer id,
                                  String nombre,
                                  String direccion,
                                  String correo,
                                  String telefono,
                                  String contrasena,
                                  MultipartFile foto) throws IOException {

        Usuario usuario = obtenerPorId(id);

        usuario.setNombre(nombre);
        usuario.setDireccion(direccion);
        usuario.setCorreo(correo);
        usuario.setTelefono(telefono);

        if (contrasena != null && !contrasena.isEmpty()) {
            usuario.setContrasena(contrasena);
        }

        // SI HAY FOTO NUEVA
        if (foto != null && !foto.isEmpty()) {

            String fileName = "user_" + id + "_" + foto.getOriginalFilename();

            Path uploadPath = Paths.get("uploads/");

            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(fileName);
            Files.write(filePath, foto.getBytes());

            usuario.setFoto(fileName);
        }

        return usuarioRepository.save(usuario);
    }

    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

}
