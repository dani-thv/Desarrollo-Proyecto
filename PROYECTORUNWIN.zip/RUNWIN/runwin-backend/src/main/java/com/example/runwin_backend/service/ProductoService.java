package com.example.runwin_backend.service;

import com.example.runwin_backend.dto.ProductoDescuentoDTO;
import com.example.runwin_backend.model.Producto;
import com.example.runwin_backend.repository.ProductoRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProductoService {

    private final ProductoRepository productoRepo;

    public ProductoService(ProductoRepository productoRepo) {
        this.productoRepo = productoRepo;
    }

    public Producto obtenerProducto(Integer id) {
        return productoRepo.findById(id).orElse(null);
    }

    public List<Producto> obtenerProductosNormales(Integer categoriaId) {
        return productoRepo.findByCategoriaId(categoriaId);
    }

    public List<ProductoDescuentoDTO> obtenerProductosConDescuento(Integer categoriaId) {

        List<Object[]> resultados = productoRepo.obtenerProductosConDescuento(categoriaId);
        List<ProductoDescuentoDTO> lista = new ArrayList<>();

        for (Object[] row : resultados) {
            Integer id = ((Number) row[0]).intValue();
            String nombre = (String) row[1];
            Integer precio = ((Number) row[2]).intValue();
            Integer porcentaje = ((Number) row[3]).intValue();
            Integer precioFinal = ((Number) row[4]).intValue();
            String imagen = (String) row[5];

            lista.add(new ProductoDescuentoDTO(id, nombre, precio, porcentaje, precioFinal, imagen));
        }

        return lista;
    }

    // Listar todos los productos
    public List<Producto> listarTodos() {
        return productoRepo.findByActivoTrue();
    }

    public Producto crearProducto(String nombre,
                                  Integer precio,
                                  Integer categoriaId,
                                  String descripcion,
                                  MultipartFile imagen) throws IOException {

        String nombreImagen = null;

        // Guardar imagen solo si viene
        if (imagen != null && !imagen.isEmpty()) {
            nombreImagen = System.currentTimeMillis() + "_" + imagen.getOriginalFilename();
            Path rutaImagen = Paths.get("uploads/" + nombreImagen);

            Files.createDirectories(rutaImagen.getParent());
            Files.copy(imagen.getInputStream(), rutaImagen);
        }

        Producto p = new Producto();
        p.setNombre(nombre);
        p.setPrecio(precio);
        p.setCategoriaId(categoriaId);
        p.setDescripcion(descripcion);
        p.setImagen(nombreImagen);

        return productoRepo.save(p);
    }
    public Producto actualizarProducto(Integer id, String nombre, Integer precio, MultipartFile imagen) throws IOException {

        Producto producto = productoRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        producto.setNombre(nombre);
        producto.setPrecio(precio);

        // Si trae nueva imagen → reemplazar
        if (imagen != null && !imagen.isEmpty()) {

            String nombreArchivo = System.currentTimeMillis() + "_" + imagen.getOriginalFilename();
            Path ruta = Paths.get("uploads").resolve(nombreArchivo);

            Files.copy(imagen.getInputStream(), ruta);

            producto.setImagen(nombreArchivo);
        }

        return productoRepo.save(producto);
    }

    @Transactional
    public void eliminarProducto(Integer id) {

        Producto producto = productoRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        // NO SE ELIMINA IMAGEN
        // NO SE ELIMINA DE BD

        producto.setActivo(false);
        productoRepo.save(producto);
    }

    public List<Producto> buscarPorNombre(String nombre) {
        return productoRepo.findByNombreContainingIgnoreCase(nombre);
    }


}
