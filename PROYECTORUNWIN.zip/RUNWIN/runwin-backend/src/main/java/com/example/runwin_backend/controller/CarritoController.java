package com.example.runwin_backend.controller;

import com.example.runwin_backend.model.CarritoItem;
import com.example.runwin_backend.service.CarritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/carrito")

public class CarritoController {

    @Autowired
    private CarritoService carritoService;

    @GetMapping("/{usuarioId}")
    public List<Map<String, Object>> obtenerCarrito(@PathVariable Integer usuarioId) {
        return carritoService.obtenerItems(usuarioId);
    }


    @PostMapping("/{usuarioId}/agregar/{productoId}")
    public CarritoItem agregar(@PathVariable Integer usuarioId, @PathVariable Integer productoId) {
        return carritoService.agregarItem(usuarioId, productoId);
    }

    @PutMapping("/item/{itemId}")
    public CarritoItem actualizarCantidad(@PathVariable Integer itemId, @RequestParam Integer cantidad) {
        return carritoService.actualizarCantidad(itemId, cantidad);
    }

    @DeleteMapping("/item/{itemId}")
    public void eliminar(@PathVariable Integer itemId) {
        carritoService.eliminarItem(itemId);
    }

    @DeleteMapping("/vaciar/{usuarioId}")
    public void vaciarCarrito(@PathVariable Integer usuarioId) {
        carritoService.vaciarCarrito(usuarioId);
    }


}
