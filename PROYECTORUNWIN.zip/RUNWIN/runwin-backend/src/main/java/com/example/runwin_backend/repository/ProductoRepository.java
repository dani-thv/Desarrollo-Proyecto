package com.example.runwin_backend.repository;

import com.example.runwin_backend.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {
    List<Producto> findByCategoriaId(Integer categoriaId);

    @Query(value =
            "SELECT p.id AS id, p.nombre AS nombre, p.precio AS precio, " +
                    "d.porcentaje AS porcentaje, " +
                    "(p.precio - (p.precio * d.porcentaje / 100)) AS precioFinal, " +
                    "p.imagen AS imagen " +
                    "FROM productos p " +
                    "JOIN descuentos d ON p.id = d.producto_id " +
                    "WHERE p.categoria_id = :categoriaId",
            nativeQuery = true)
    List<Object[]> obtenerProductosConDescuento(Integer categoriaId);
    List<Producto> findByActivoTrue();
    List<Producto> findByNombreContainingIgnoreCase(String nombre);
}
