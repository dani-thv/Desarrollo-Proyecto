package com.example.runwin_backend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProductoDescuentoDTO {
    private Integer id;
    private String nombre;
    private Integer precio;
    private Integer porcentaje;
    private Integer precioFinal;
    private String imagen;
}
