package com.example.runwin_backend.controller;

import com.example.runwin_backend.model.Pedido;
import com.example.runwin_backend.model.PedidoItem;
import com.example.runwin_backend.service.PedidoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    // 👉 historial por usuario
    @GetMapping("/usuario/{usuarioId}")
    public List<Pedido> listarPorUsuario(@PathVariable Integer usuarioId) {
        return pedidoService.listarPorUsuario(usuarioId);
    }

    // 👉 detalle del pedido con items
    @GetMapping("/{id}")
    public Pedido obtenerPedido(@PathVariable Integer id) {
        return pedidoService.obtenerPedidoConItems(id);
    }

    @PostMapping
    public Pedido crearPedido(@RequestBody Pedido pedido) {
        return pedidoService.crearPedido(pedido);
    }

    @PostMapping("/detalle")
    public PedidoItem agregarItem(@RequestBody PedidoItem item) {
        return pedidoService.agregarItem(item);
    }

    @GetMapping
    public List<Pedido> listarTodos() {
        return pedidoService.listarTodos();
    }




}

