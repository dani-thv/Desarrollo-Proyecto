package com.example.runwin_backend.repository;

import com.example.runwin_backend.model.TipDeportivo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TipDeportivoRepository extends JpaRepository<TipDeportivo, Integer> {

    @Query(value = """
        SELECT t.id, t.titulo, t.contenido, 
               p.nombre AS producto_nombre, 
               p.imagen AS producto_imagen, 
               p.precio AS producto_precio
        FROM tips_deportivos t
        JOIN productos p ON t.producto_id = p.id
        ORDER BY RANDOM()
        LIMIT 3
        """,
            nativeQuery = true)
    List<Object[]> obtenerTresTipsAleatorios();
}
