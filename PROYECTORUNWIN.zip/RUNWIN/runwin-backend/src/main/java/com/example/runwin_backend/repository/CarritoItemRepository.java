package com.example.runwin_backend.repository;

import com.example.runwin_backend.model.CarritoItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CarritoItemRepository extends JpaRepository<CarritoItem, Integer> {

    List<CarritoItem> findByCarritoId(Integer carritoId);

    // 🔥 Necesario para vaciar el carrito
    void deleteByCarritoId(Integer carritoId);
}
