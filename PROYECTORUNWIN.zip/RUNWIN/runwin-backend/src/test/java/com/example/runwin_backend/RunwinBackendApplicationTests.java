package com.example.runwin_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunwinBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
