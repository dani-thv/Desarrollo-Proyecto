document.addEventListener("DOMContentLoaded", () => {

    const usuario = JSON.parse(localStorage.getItem("usuario"));

    if (!usuario) {
        window.location.href = "inicio_sesion.html";
        return;
    }

    
    document.getElementById("configNombre").textContent = usuario.nombre;
    document.getElementById("configRol").textContent = usuario.rol;

    // Inputs del formulario
    document.getElementById("nombre").value = usuario.nombre;
    document.getElementById("direccion").value = usuario.direccion;
    document.getElementById("correo").value = usuario.correo;
    document.getElementById("telefono").value = usuario.telefono || "";

    
    if (usuario.foto) {
        document.getElementById("fotoUsuario").src =
            "http://localhost:8081/uploads/" + usuario.foto;
    }

    
    document.querySelector(".btn-guardar").addEventListener("click", async () => {

        const archivo = document.getElementById("inputFoto").files[0];

        
        if (archivo) {

            const formData = new FormData();
            formData.append("id", usuario.id);
            formData.append("nombre", document.getElementById("nombre").value);
            formData.append("direccion", document.getElementById("direccion").value);
            formData.append("correo", document.getElementById("correo").value);
            formData.append("telefono", document.getElementById("telefono").value);
            formData.append("contrasena", document.getElementById("password").value);
            formData.append("foto", archivo);

            const respuesta = await fetch("http://localhost:8081/api/usuarios/actualizarFoto", {
                method: "PUT",
                body: formData
            });

            if (respuesta.ok) {
                const usuarioActualizado = await respuesta.json();
                localStorage.setItem("usuario", JSON.stringify(usuarioActualizado));

               
                document.getElementById("fotoUsuario").src =
                    "http://localhost:8081/uploads/" + usuarioActualizado.foto;

            
                document.getElementById("configNombre").textContent = usuarioActualizado.nombre;

                alert("Cambios guardados correctamente");
            } else {
                alert("Error al guardar cambios");
            }

            return;
        }

        
        const data = {
            id: usuario.id,
            nombre: document.getElementById("nombre").value,
            direccion: document.getElementById("direccion").value,
            correo: document.getElementById("correo").value,
            telefono: document.getElementById("telefono").value,
            contrasena: document.getElementById("password").value
        };

        const respuesta = await fetch("http://localhost:8081/api/usuarios/actualizar", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        if (respuesta.ok) {
            const usuarioActualizado = await respuesta.json();
            localStorage.setItem("usuario", JSON.stringify(usuarioActualizado));

           
            document.getElementById("configNombre").textContent = usuarioActualizado.nombre;

            alert("Cambios guardados correctamente");


            document.getElementById("input-nombre").value = "";
            document.getElementById("input-direccion").value = "";
            document.getElementById("input-correo").value = "";
            document.getElementById("input-telefono").value = "";
            document.getElementById("input-contrasena").value = "";
            
        } else {
            alert("Error al guardar cambios");
        }

    });
        document.getElementById("cerrar-sesion").addEventListener("click", () => {
        localStorage.removeItem("usuario");
        window.location.href = "inicio_sesion.html";
    });
});
