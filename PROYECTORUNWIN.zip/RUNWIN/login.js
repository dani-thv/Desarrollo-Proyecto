document.getElementById("btn-login").addEventListener("click", function (e) {
    e.preventDefault();

    const correo = document.getElementById("login-correo").value;
    const contrasena = document.getElementById("login-contrasena").value;

    fetch("http://localhost:8081/api/usuarios/login", {
        method: "POST",
        headers: { 
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        body: JSON.stringify({ correo, contrasena })
    })
    .then(async res => {
        const data = await res.json();

        // Si el backend devolvió error
        if (!res.ok) {
            mostrarError(data.error || "Correo o contraseña incorrectos");
            return;
        }


        localStorage.setItem("usuario", JSON.stringify(data));


        if (data.rol === "ADMIN") {
            window.location.href = "admin_panel.html"; // panel administrador
        } else {
            window.location.href = "panel.html"; // panel usuario normal
        }
    })
    .catch(err => {
        console.error(err);
        mostrarError("Error al iniciar sesión");
    });
});


function mostrarError(msg) {
    const div = document.createElement("div");
    div.className = "alerta-error";
    div.innerText = msg;

    document.body.appendChild(div);

    setTimeout(() => div.remove(), 2500);
}
