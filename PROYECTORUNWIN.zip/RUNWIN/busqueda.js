document.addEventListener("DOMContentLoaded", () => {
    const params = new URLSearchParams(window.location.search);
    const query = params.get("q");

    if (!query) {
        mostrarMensaje("Escribe algo en la búsqueda.");
        return;
    }

    buscarProductos(query);
});


// BUSCAR EN EL BACKEND

async function buscarProductos(texto) {
    const contenedor = document.getElementById("resultados");

    try {
        const url = `http://localhost:8081/api/productos/buscar?nombre=${encodeURIComponent(texto)}`;
        const resp = await fetch(url);

        if (!resp.ok) throw new Error("No se pudo buscar");

        const productos = await resp.json();

        if (productos.length === 0) {
            mostrarMensaje(`No se encontraron resultados para: "${texto}"`);
            return;
        }

        contenedor.innerHTML = "";

        productos.forEach(prod => {
            let imagenSrc;

     
            // LÓGICA DE IMÁGENES
    
            if (!prod.imagen) {
                // Sin imagen → placeholder
                imagenSrc = "https://placehold.co/400x400?text=Sin+Imagen";
            } 
            else if (/^\d/.test(prod.imagen)) {
                // Empieza por número → viene del backend (/uploads)
                imagenSrc = `http://localhost:8081/uploads/${prod.imagen}`;
            } 
            else {
                // Ruta local del frontend
                imagenSrc = prod.imagen;
            }


            // CARD DEL PRODUCTO
         
            const card = document.createElement("div");
            card.classList.add("producto-card");

            card.innerHTML = `
                <img class="producto-img" src="${imagenSrc}" alt="${prod.nombre}">
                <h3 class="producto-nombre">${prod.nombre}</h3>
                <p class="producto-precio">COP ${prod.precio.toLocaleString("es-CO")}</p>

                <div class="producto-botones">
                    <button class="btn-agregar" onclick="agregarAlCarrito(${prod.id})">
                        🛒 Agregar al carrito
                    </button>

                    <button class="btn-deseos" onclick="agregarWishlist(${prod.id})">
                        🤍 Deseos
                    </button>
                </div>
            `;

            contenedor.appendChild(card);
        });

    } catch (err) {
        mostrarMensaje("Error buscando los productos.");
        console.error(err);
    }
}


// MENSAJE SIN RESULTADOS

function mostrarMensaje(msg) {
    document.getElementById("resultados").innerHTML = `
        <p class="text-gray-500 p-4 text-center">${msg}</p>
    `;
}
