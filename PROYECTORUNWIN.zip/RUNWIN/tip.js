document.addEventListener("DOMContentLoaded", cargarTips);

async function cargarTips() {
    const contenedor = document.querySelector(".tips-section");

    try {
        const respuesta = await fetch("http://localhost:8081/api/tips/aleatorios");
        const tips = await respuesta.json();

        contenedor.innerHTML = "";

        let colores = ["color-1", "color-2", "color-3", "color-4"];
        let colorIndex = 0;

        tips.forEach((tip, index) => {

            const card = document.createElement("div");
            card.classList.add("tip-card");

            if (index % 2 === 1) card.classList.add("even-tip");

            const colorClass = colores[colorIndex];
            colorIndex = (colorIndex + 1) % colores.length;

            card.innerHTML = `
                <div class="tip-content">
                    <h2 class="tip-title">${tip.titulo}</h2>
                    <p class="tip-text">${tip.contenido}</p>
                    <span class="tag">${tip.productoNombre}</span>
                </div>

                <div class="tip-image-container ${colorClass}" onclick="irAProducto(${tip.id})">
                    <img src="${tip.productoImagen}" class="tip-image">
                </div>
            `;

            contenedor.appendChild(card);

            setTimeout(() => card.classList.add("visible"), index * 200);
        });

    } catch (error) {
        console.error("Error cargando tips:", error);
    }
}

function irAProducto(idTip) {

    // Redirigir a la tienda general
    
    window.location.href = "productos.html";
}
