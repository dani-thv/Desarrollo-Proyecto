document.addEventListener("DOMContentLoaded", async () => {

    function formatearFecha(fechaISO) {
        const fecha = new Date(fechaISO);
        return fecha.toLocaleDateString("es-CO", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            timeZone: 'UTC'
        });
    }

    const usuario = JSON.parse(localStorage.getItem("usuario"));

    if (!usuario) {
        window.location.href = "inicio_sesion.html";
        return;
    }

    const tabla = document.getElementById("tabla-pedidos");

    try {
        const respuesta = await fetch(`http://localhost:8081/api/pedidos/usuario/${usuario.id}`);

        if (!respuesta.ok) {
            throw new Error("No se pudieron obtener los pedidos");
        }

        const pedidos = await respuesta.json();

        tabla.innerHTML = "";

        // SI EL USUARIO NO TIENE HISTORIAL
        if (pedidos.length === 0) {
            tabla.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align:center; padding:20px; color:#666;">
                        No tienes compras registradas todavía.
                    </td>
                </tr>`;
            return;
        }

    
        let contador = 1;

        pedidos.forEach(p => {
            const fechaFormateada = formatearFecha(p.fecha);

            tabla.innerHTML += `
                <tr>
                    <td>#${contador++}</td> <!-- ID virtual mostrado -->
                    <td>${fechaFormateada}</td>
                    <td>COP ${Number(p.total).toLocaleString("es-CO")}</td>
                    <td>${p.estado}</td>
                    <td>
                        <a href="detalle_pedido.html?id=${p.id}" class="btn-detalle">
                            Ver detalles
                        </a>
                    </td>
                </tr>
            `;
        });

    } catch (error) {
        console.error(error);

        tabla.innerHTML = `
            <tr>
                <td colspan="5" style="text-align:center; padding:20px; color:red;">
                    Error al cargar el historial.
                </td>
            </tr>`;
    }
});

// Cerrar sesión
document.getElementById("cerrar-sesion").addEventListener("click", () => {
    localStorage.removeItem("usuario");
    window.location.href = "inicio_sesion.html";
});
