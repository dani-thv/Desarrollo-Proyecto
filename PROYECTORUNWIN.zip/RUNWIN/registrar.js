// -------------------------------
// Mostrar / ocultar contraseña
// -------------------------------
function togglePassword(id, element) {
    const input = document.getElementById(id);
    const icon = element.querySelector("i");

    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
    } else {
        input.type = "password";
        icon.classList.add("fa-eye");
        icon.classList.remove("fa-eye-slash");
    }
}



// -------------------------------
// Registro de usuario
// -------------------------------
document.getElementById("form-registro").addEventListener("submit", function (e) {
    e.preventDefault();

    const nombre = document.getElementById("nombre").value.trim();
    const correo = document.getElementById("correo").value.trim();
    const contrasena = document.getElementById("contrasena").value.trim();
    const confirmar = document.getElementById("confirmar").value.trim();
    const terminos = document.getElementById("terminos").checked;

    // Validaciones
    if (!nombre || !correo || !contrasena || !confirmar) {
        alert("Por favor completa todos los campos.");
        return;
    }

    if (contrasena !== confirmar) {
        alert("Las contraseñas no coinciden.");
        return;
    }

    if (!terminos) {
        alert("Debes aceptar los términos y condiciones.");
        return;
    }

    // Objeto que enviamos al backend
    const usuario = {
        nombre: nombre,
        correo: correo,
        contrasena: contrasena,
        rol: "CLIENTE" // POR DEFECTO PARA TU PROYECTO
    };

    // REALIZAR REGISTRO
    fetch("http://localhost:8081/api/usuarios/registro", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(usuario)
    })
        .then(res => {
            if (!res.ok) {
                throw new Error("Error al registrar (correo ya existe o falla del servidor).");
            }
            return res.json();
        })
        .then(data => {
            alert("Cuenta creada exitosamente 🎉");

            // Guardar sesión
            localStorage.setItem("usuario", JSON.stringify(data));

            // Redirigir al inicio de sesión
            window.location.href = "inicio_sesion.html";
        })
        .catch(err => {
            console.error(err);
            alert("No se pudo registrar. Verifica el correo o intenta más tarde.");
        });
});
