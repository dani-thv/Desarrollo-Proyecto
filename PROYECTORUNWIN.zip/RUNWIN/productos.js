const usuario = JSON.parse(localStorage.getItem("usuario"));

async function cargarProductos(categoria) {
    try {
        const respuesta = await fetch(`http://localhost:8081/api/productos/categoria/${categoria}`);
        const productos = await respuesta.json();

        const contenedor = document.querySelector(".productos-container");
        contenedor.innerHTML = "";

        productos.forEach(p => {
            contenedor.innerHTML += `
                <div class="product-card">
                    <img src="${p.imagen}" alt="" class="product-img">
                    <h3>${p.nombre}</h3>
                    <p>COP ${p.precio.toLocaleString()}</p>
                    <button onclick="agregarAlCarrito(${p.id})">Agregar al carrito</button>
                </div>
            `;
        });

    } catch (error) {
        console.error("Error cargando productos:", error);
    }
}

function agregarAlCarrito(productoId) {

    // No logueado → Login
    if (!usuario) {
        window.location.href = "inicio_sesion.html";
        return;
    }

    // Logueado → Añadir
    fetch(`http://localhost:8081/api/carrito/${usuario.id}/agregar/${productoId}`, {
        method: "POST"
    })
    .then(r => r.json())
    .then(() => {
        alert("Producto agregado al carrito");
    })
    .catch(err => console.error(err));
}
