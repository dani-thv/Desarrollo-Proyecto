document.addEventListener("DOMContentLoaded", () => {


const searchBtn = document.getElementById("searchBtn");
const searchInput = document.getElementById("searchInput");

if (searchBtn && searchInput) {
    

    function obtenerRutaBase() {

        const pathParts = window.location.pathname.split('/');
        pathParts.pop(); 
 
        return pathParts.join('/') + '/'; 
    }
    
    // Obtener la ruta base una sola vez
    const RUTA_BASE = obtenerRutaBase();

    searchBtn.addEventListener("click", () => {
        const texto = searchInput.value.trim();
        if (texto !== "") {
            
            // Usamos la ruta base + el nombre del archivo
            window.location.href = `${RUTA_BASE}busqueda.html?q=${encodeURIComponent(texto)}`;
            

        }
    });
    

}

});
