function getImagenSrc(nombre) {

    if (!nombre) {
        return "https://placehold.co/400x400?text=Sin+Imagen";
    }

    // Si empieza por número → imagen del backend (/uploads/)
    if (/^\d/.test(nombre)) {
        return `http://localhost:8081/uploads/${nombre}`;
    }

    // Si es una imagen vieja del frontend
    return `${nombre}`;
}

function requireLogin() {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (!usuario) {
        alert("Debes iniciar sesión para continuar");
        window.location.href = "inicio_sesion.html";
        return null;
    }
    return usuario;
}

document.addEventListener("DOMContentLoaded", async () => {

    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (!usuario) {
        alert("Debes iniciar sesión");
        window.location.href = "inicio_sesion.html";
        return;
    }

    const tabla = document.getElementById("wishlist-body");

    try {
        // Obtener lista de deseos del usuario
        const res = await fetch(`http://localhost:8081/api/wishlist/${usuario.id}`);
        if (!res.ok) throw new Error("Error al obtener wishlist");

        const lista = await res.json();
        tabla.innerHTML = "";

        // Si está vacía
        if (lista.length === 0) {
            tabla.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center; padding:20px;">
                        No tienes productos en tu lista de deseos.
                    </td>
                </tr>`;
            return;
        }

        // Rellenar datos → obtener producto por ID
        for (const item of lista) {

            const prodRes = await fetch(`http://localhost:8081/api/productos/${item.productoId}`);
            const producto = await prodRes.json();

            const precio = Number(producto.precio).toLocaleString("es-CO");

const imagen = getImagenSrc(producto.imagen);

tabla.innerHTML += `
    <tr data-uid="${item.usuarioId}" data-pid="${item.productoId}">
        <td class="product-info">
            <img src="${imagen}" class="product-img">
            <div><strong>${producto.nombre}</strong></div>
        </td>
        <td><strong>COP ${precio}</strong></td>
        <td>
            <span class="wishlist-status available">Disponible</span>
        </td>
        <td class="actions">
            <button class="add-cart-btn" onclick="agregarDesdeWishlist(${item.productoId})">
                Agregar al carrito
            </button>
            <button class="remove-btn">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </td>
    </tr>
`;

        }

        // Accionar botón "Eliminar"
        document.querySelectorAll(".remove-btn").forEach(btn =>
            btn.addEventListener("click", async (e) => {
                const tr = e.currentTarget.closest("tr");
                const usuarioId = tr.dataset.uid;
                const productoId = tr.dataset.pid;

                await eliminarItem(usuarioId, productoId);
            })
        );

    } catch (err) {
        console.error(err);
        alert("Error al cargar lista de deseos");
    }

});





async function eliminarItem(usuarioId, productoId) {

    const res = await fetch(`http://localhost:8081/api/wishlist/${usuarioId}/${productoId}`, {
        method: "DELETE"
    });

    if (res.ok) {
        location.reload();
    } else {
        alert("Error al eliminar el producto");
    }
}




async function agregarDesdeWishlist(productoId) {

    const usuario = JSON.parse(localStorage.getItem("usuario"));

    if (!usuario) {
        window.location.href = "inicio_sesion.html";
        return;
    }

    try {
        const res = await fetch(`http://localhost:8081/api/carrito/${usuario.id}/agregar/${productoId}`, {
            method: "POST"
        });

        if (res.ok) {
            alert("Producto agregado al carrito 🛒");


            await eliminarItem(usuario.id, productoId);

        } else {
            alert("No se pudo agregar al carrito");
        }

    } catch (err) {
        console.error("Error al agregar desde wishlist:", err);
    }
}


// CERRAR SESIÓN

document.getElementById("cerrar-sesion").addEventListener("click", () => {
    localStorage.removeItem("usuario");
    window.location.href = "inicio_sesion.html";
});
async function agregarWishlist(productoId) {

    const usuario = requireLogin();
    if (!usuario) return;

    try {
        const res = await fetch(`http://localhost:8081/api/wishlist/${usuario.id}/${productoId}`, {
            method: "POST"
        });

        if (!res.ok) throw new Error("Error al agregar a wishlist");

        alert("Agregado a tu lista de deseos ❤️");

    } catch (e) {
        console.error(e);
        alert("No se pudo agregar a la wishlist");
    }
}
