document.addEventListener("DOMContentLoaded", () => {

    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (!usuario) return;

    const current = location.pathname;

    // ---------------------------------------------------------
    // 1. BLOQUEAR CLIENTE EN PÁGINAS ADMIN
    // ---------------------------------------------------------
    if (usuario.rol === "CLIENTE") {
        if (current.includes("admin_panel")) {
            window.location.href = "panel.html";
        }
        return; // IMPORTANTE: parar ejecución
    }

    // ---------------------------------------------------------
    // 2. BLOQUEAR ADMIN EN PÁGINAS DE CLIENTE
    // ---------------------------------------------------------
    if (usuario.rol === "ADMIN") {

        // Páginas exclusivas del cliente
        const clientPages = [
            "/panel.html",
            "/carrito.html",
            "/lista_deseos.html",
            "/hombre.html",
            "/mujer.html",
            "/nino.html",
            "/descuentos.html",
            "/tips_deportivos.html"
        ];

        // 👉 Importante: si ya estamos en admin_panel, NO redirigir
        if (!current.includes("admin_panel") &&
            clientPages.some(p => current.endsWith(p))) {

            window.location.href = "admin_panel.html";
            return;
        }

        // ---------------------------------------------------------
        // 3. QUITAR BOTONES QUE NO DEBEN VER
        // ---------------------------------------------------------
        document.querySelectorAll(".btn-agregar-carrito").forEach(b => b.remove());
        document.querySelectorAll(".btn-deseo").forEach(b => b.remove());
        document.querySelectorAll(".btn-comprar").forEach(b => b.remove());
    }
});
